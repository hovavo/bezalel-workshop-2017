project.svgName = 'design.svg';

project.svgReady = function () {

    // A place for code that should happen 
    // once the design is loaded
    
    view.onFrame = function () {
        
        // A place for code that should
        // repeat on every frame 
        
    }
}